<?php
$config = array(
	"type" => "1",//公告展现形式1为弹出层，2为底部固定
	"show" => "0",//显示页面，0为所有页面，1为首页
	"callt" => false,//是否直接调用微语数据，为true时content无效
	"num" => "0",//调取微语条数
	"content" => "新博客！"
);