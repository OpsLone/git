<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="wrap">
	<div class="mainleft">
		<div class="list content">
			<div class="item">
				<div class="l">
					<div class="date">
						<div class="t">
							<?php echo gmdate('j', $date); ?>
						</div>
						<div class="b"><?php echo gmdate('Y-n', $date); ?></div>
					</div>
				</div>
				<div class="r">
					<div class="m">
						<div class="t position"><span class="jiao"></span>
							<span class="inner">
								<a href="<?php echo BLOG_URL;?>" title="返回首页">首页</a> >> <?php echo $log_title; ?>
							</span>
						</div>
						<h3><?php echo $log_title; ?><span class="e"><?php editflg($logid,$author); ?></span></h3>
						<div class="con">
							<?php echo $log_content; ?>
						</div>
						<div class="meta">
							<div class="tag">
								<span class="author">编辑：<?php blog_author($author); ?></span>
							</div>
							<div class="view"></div>
							<div class="clear"></div>
						</div>
					</div>
					<div class="b"></div>
				</div>
				<div class="clear"></div>
			</div><!--//item end-->
			<div class="item">
				<div class="l">
				</div>
				<div class="r">
					<div class="m">
						<div class="t"></div>
						<div class="con">
							<?php blog_comments($comments); ?>
							<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
						</div>
					</div>
					<div class="b"></div>
				</div>
				<div class="clear"></div>
			</div><!--//item end-->
		</div><!--//list end-->
	</div>
	<div class="mainright">
		<?php
			include View::getView('side');
		?>
	</div><!-- //mainright end-->
	<div class="clear"></div>
<?php
 include View::getView('footer');
?>