<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->
<div style="clear:both;"></div>
<div id="footerbar">
	<h6 style="font-size:1;font-style:italic;font-weight: normal">Powered by <a href="http://www.emlog.net" title="采用emlog系统">emlog</a></h6> 
	<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1256061560'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s11.cnzz.com/z_stat.php%3Fid%3D1256061560%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</script>
	<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
	<?php doAction('index_footer'); ?>
	
</div><!--end #footerbar-->
</div><!--end #wrap-->
<script>prettyPrint();</script>

</body>
</html>