<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="wrap">
	<div class="mainleft">
		<?php if(blog_tool_ishome()):?>
		<div class="blocks">
			<div class="l">
				<?php myPhoto();?>
			</div>
			<div class="r">
				<ul><!--下面4个链接，对应首页博主头像右侧4个图标-->
					<li class="one"><a href=""></a></li>
					<li class="two"><a href=""></a></li>
					<li class="three"><a href=""></a></li>
					<li class="four"><a href=""></a></li>
				</ul>
			</div>
			<div class="clear"></div>
		</div>
		<div class="notice">
			<div class="r">
				<div class="t"></div>
				<div class="m">
					<h2>公告</h2>
					<div class="con">
						欢迎大家访问我的博客！
<?php doAction('index_loglist_top'); ?>
					</div>
				</div>
				<div class="b"></div>
			</div>
			<div class="clear"></div>
		</div>
		<?php else:?>
		<div class="bread">
			<h3>
<?php if ($params[1]=='sort'){ ?>
			<b>分类“<?php echo $sortName; ?>”</b>
<?php }elseif ($params[1]=='tag'){ ?>
			<b>标签“<?php echo urldecode($params[2]);?>”</b>
<?php }elseif($params[1]=='author'){ ?>
			<b>作者“<?php echo blog_author($author);?>”发布的内容</b> 
<?php }elseif($params[1]=='keyword'){ ?>
            <b>关键词“<?php echo urldecode($params[2]);?>”的搜索结果</b> 
<?php }elseif($params[1]=='record'){ ?>
            <b>发表在“<?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?>”的内容</b>
				<?php }else{}?>
			</h3>
		</div>
		<div class="clear"></div>
		<?php endif;?>
		<div class="list">
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
			<div class="item list-item">
				<div class="l">
					<div class="date">
						<div class="t">
							<?php echo gmdate('j', $value['date']); ?> 
						</div>
						<div class="b"><?php echo gmdate('Y-n', $value['date']); ?></div>
					</div>
					<div class="tags">
						<?php blogtags($value['logid']); ?>
					</div>
				</div>
				<div class="r">
					<div class="m">
						<div class="t"><span class="jiao"></span></div>
						<h3><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a><span class="e"><?php editflg($value['logid'],$value['author']); ?></span></h3>
						<div class="con">
							<?php echo strip_tags(subString($value['log_description'],0,200)); ?>
						</div>
						<div class="meta">
							<div class="tag">
								<span class="author">作者：<?php blog_author($value['author']); ?></span>
								<span class="cat"><?php blog_sort($value['logid']); ?></span>
							</div>
							<div class="view">
								<span class="v">浏览：<?php echo $value['views']; ?></span>
								<span class="c">评论：<?php echo $value['comnum']; ?></span>
							</div>
							<div class="clear"></div>
						</div>
					</div>
					<div class="b"></div>
				</div>
				<div class="clear"></div>
			</div><!--//item end-->
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>

<div id="pagenavi">
	<?php echo $page_url;?>
	<div class="clear"></div>
</div>
		</div><!--//list end-->
	</div>
	<div class="mainright">
		<?php
			include View::getView('side');
		?>
	</div><!-- //mainright end-->
	<div class="clear"></div>
<?php
 include View::getView('footer');
?>
