#version:emlog 5.3.1
#date:2016-04-27 10:51
#tableprefix:emlog_
DROP TABLE IF EXISTS emlog_attachment;
CREATE TABLE `emlog_attachment` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `blogid` int(10) unsigned NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) NOT NULL DEFAULT '0',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `addtime` bigint(20) NOT NULL DEFAULT '0',
  `width` int(10) NOT NULL DEFAULT '0',
  `height` int(10) NOT NULL DEFAULT '0',
  `mimetype` varchar(40) NOT NULL DEFAULT '',
  `thumfor` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`),
  KEY `blogid` (`blogid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO emlog_attachment VALUES('1','2','QQ图片.jpg','53584','../content/uploadfile/201508/d3d41439516726.jpg','1439516726','615','415','image/jpeg','0');
INSERT INTO emlog_attachment VALUES('2','2','QQ图片.jpg','23906','../content/uploadfile/201508/thum-d3d41439516726.jpg','1439516726','420','284','image/jpeg','1');
INSERT INTO emlog_attachment VALUES('3','16','1.png','391364','../content/uploadfile/201509/4a471441121138.png','1441121138','993','566','image/png','0');
INSERT INTO emlog_attachment VALUES('4','16','1.png','102816','../content/uploadfile/201509/thum-4a471441121138.png','1441121138','420','240','image/png','3');


#the end of backup