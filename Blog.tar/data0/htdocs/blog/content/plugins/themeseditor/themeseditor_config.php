<?php
define('THEMESEDITOR_CTHEME','KEcho1_1');
define('THEMESEDITOR_CFILE','side.php');
define('CODEMIRROR_THEME','ambiance');
define('THEMESEDITOR_EDITOR_THEMES',"ambiance,blackboard,cobalt,eclipse,elegant,erlang-dark,lesser-dark,monokai,neat,night,rubyblue,twilight,vibrant-ink,xq-dark");
