<?php
//mysql database address
define('DB_HOST','localhost');
//mysql database user
define('DB_USER','root');
//database password
define('DB_PASSWD','123456');
//database name
define('DB_NAME','myblog');
//database prefix
define('DB_PREFIX','emlog_');
//auth key
define('AUTH_KEY','(VV)aNC6qtIH8JzWuJvmxMEe8jhowaIt44c7615a86a578b72f718a4e8c5a3d5a');
//cookie name
define('AUTH_COOKIE_NAME','EM_AUTHCOOKIE_TOsGXlfUiBD8ftyLKTxPmv6WIAaecbsB');
